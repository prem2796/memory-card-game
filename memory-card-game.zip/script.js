(() => {
  "use strict";

  // Emoji pool (use many to accommodate up to 36 cards = 18 pairs)
  const EMOJIS = [
    "🐶","🐱","🦊","🐼","🐵","🐯","🦁","🐸","🐷","🐮","🐔","🐺","🦄","🐙","🦉","🦋","🐢","🐞",
    "🍎","🍌","🍇","🍉","🍓","🍒","🍍","🥝","🍑","🍊","🥑","🌶️",
    "⚽","🏀","🏈","🎾","🏐","🎳","🥏","🎯",
    "🚗","🚕","🚌","🚓","🚑","🚒","🚜","✈️","🚀","🛸",
    "🌈","⭐","🔥","🍀","❄️","🌙","☀️","⚡","💧","🪐"
  ];

  const state = {
    size: 16,              // total cards
    first: null,           // first flipped element
    lock: false,           // board lock during animations
    moves: 0,
    matchedPairs: 0,
    timer: { started: false, startAt: 0, id: 0 }
  };

  // Elements
  const gameEl = document.getElementById("game");
  const timeEl = document.getElementById("time");
  const movesEl = document.getElementById("moves");
  const diffEl = document.getElementById("difficulty");
  const newBtn = document.getElementById("newGameBtn");
  const dialog = document.getElementById("winDialog");
  const finalTimeEl = document.getElementById("finalTime");
  const finalMovesEl = document.getElementById("finalMoves");
  const playAgainBtn = document.getElementById("playAgainBtn");

  // Utility: format seconds to mm:ss
  const fmt = (s) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2,"0")}:${String(sec).padStart(2,"0")}`;
  };

  // Timer controls
  function startTimer(){
    state.timer.started = true;
    state.timer.startAt = Date.now();
    state.timer.id = setInterval(() => {
      const secs = Math.floor((Date.now() - state.timer.startAt)/1000);
      timeEl.textContent = fmt(secs);
    }, 250);
  }
  function stopTimer(){
    if(state.timer.id) clearInterval(state.timer.id);
    state.timer.id = 0;
    state.timer.started = false;
  }
  function resetTimerUI(){
    stopTimer();
    timeEl.textContent = "00:00";
  }

  // Create a deck based on size
  function buildDeck(size){
    const pairs = size / 2;
    // Pick unique emojis
    const pool = EMOJIS.slice().sort(() => Math.random() - 0.5).slice(0, pairs);
    const deck = [...pool, ...pool] // duplicate to create pairs
      .map((symbol, idx) => ({ id: idx + 1, symbol }));
    // Fisher-Yates shuffle
    for(let i = deck.length - 1; i > 0; i--){
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
  }

  // Render grid
  function render(size){
    state.size = size;
    state.first = null;
    state.lock = false;
    state.moves = 0;
    state.matchedPairs = 0;
    movesEl.textContent = "0";
    resetTimerUI();

    const deck = buildDeck(size);
    gameEl.innerHTML = "";
    gameEl.setAttribute("data-size", String(size));

    const frag = document.createDocumentFragment();
    deck.forEach((card, index) => {
      const cardEl = document.createElement("button");
      cardEl.className = "card";
      cardEl.type = "button";
      cardEl.setAttribute("data-symbol", card.symbol);
      cardEl.setAttribute("aria-label", "Hidden card");
      cardEl.setAttribute("aria-pressed", "false");
      cardEl.setAttribute("tabindex", "0");

      const inner = document.createElement("div");
      inner.className = "card-inner";

      const front = document.createElement("div");
      front.className = "card-face card-front";
      const badge = document.createElement("div");
      badge.className = "badge";
      badge.textContent = "🧩";
      front.appendChild(badge);

      const back = document.createElement("div");
      back.className = "card-face card-back";
      back.textContent = card.symbol;

      inner.appendChild(front);
      inner.appendChild(back);
      cardEl.appendChild(inner);

      // Events
      cardEl.addEventListener("click", () => flip(cardEl));
      cardEl.addEventListener("keydown", (e) => {
        if(e.key === "Enter" || e.key === " "){
          e.preventDefault();
          flip(cardEl);
        }
      });

      frag.appendChild(cardEl);
    });
    gameEl.appendChild(frag);
  }

  function flip(cardEl){
    if(state.lock) return;
    if(cardEl.classList.contains("matched")) return;
    if(cardEl === state.first) return; // clicking the same card again

    // Start timer on first interaction
    if(!state.timer.started) startTimer();

    cardEl.classList.add("is-flipped");
    cardEl.setAttribute("aria-pressed", "true");
    cardEl.setAttribute("aria-label", `Revealed ${cardEl.dataset.symbol}`);

    if(!state.first){
      state.first = cardEl;
      return;
    }

    // Second card chosen
    const first = state.first;
    const second = cardEl;
    state.first = null;
    state.moves += 1;
    movesEl.textContent = String(state.moves);

    const isMatch = first.dataset.symbol === second.dataset.symbol;
    if(isMatch){
      first.classList.add("matched");
      second.classList.add("matched");
      // small delay to allow flip animation to complete
      setTimeout(() => {
        first.setAttribute("aria-label", `Matched ${first.dataset.symbol}`);
        second.setAttribute("aria-label", `Matched ${second.dataset.symbol}`);
      }, 200);

      state.matchedPairs += 1;
      if(state.matchedPairs === state.size / 2){
        // Win!
        stopTimer();
        finalTimeEl.textContent = timeEl.textContent;
        finalMovesEl.textContent = String(state.moves);
        // Update dialog description
        const body = document.getElementById("winBody");
        body.textContent = `You matched all ${state.size/2} pairs!`;
        openDialog();
      }
    } else {
      // Not a match: lock, then flip back
      state.lock = true;
      setTimeout(() => {
        first.classList.remove("is-flipped");
        second.classList.remove("is-flipped");
        first.setAttribute("aria-pressed", "false");
        second.setAttribute("aria-pressed", "false");
        first.setAttribute("aria-label", "Hidden card");
        second.setAttribute("aria-label", "Hidden card");
        state.lock = false;
      }, 800);
    }
  }

  function openDialog(){
    if(typeof dialog.showModal === "function"){
      dialog.showModal();
    } else {
      // Fallback for older browsers
      dialog.setAttribute("open","");
    }
  }

  function closeDialog(){
    if(dialog.hasAttribute("open")) dialog.close?.();
  }

  // Event wiring
  newBtn.addEventListener("click", () => {
    closeDialog();
    render(parseInt(diffEl.value, 10));
  });
  diffEl.addEventListener("change", () => {
    render(parseInt(diffEl.value, 10));
  });
  playAgainBtn.addEventListener("click", (e) => {
    e.preventDefault();
    closeDialog();
    render(parseInt(diffEl.value, 10));
  });

  // Initialize
  render(parseInt(diffEl.value, 10));
})();
